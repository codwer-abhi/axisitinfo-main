require('dotenv').config()
const express = require('express');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 4000;
const { connectToDatabase } = require('./utils/db');
const contactrouter=require('./Router/Contact-route');
const adminrouter = require('./Router/admin-router');
const corsOptions={
    origin: 'https://axisitinfo.com', // Replace with your frontend URL
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true, // Allow credentials (cookies, authorization headers, etc.)
}
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({extended:false}));
const allrouter=    require('./Router/auth-router');
const errorMiddleware = require('./MIddlewares/error-Middleware');
app.use('/route', allrouter);
app.use('/contact',contactrouter)
app.use('/admin', adminrouter);
app.use(errorMiddleware);
connectToDatabase(process.env.MONGODB_URI)
.then(() => {
  app.listen(port);
}).catch((error) => {
  throw error; // Re-throw the error to be handled by the caller
});